
fetch('test.json')
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.json(); 
  })
  .then(data => {
    const hotelData = data[0]; 

    function renderHotelInfo(hotelData) {
      const container = document.getElementsByClassName("Container")[0];
      container.innerHTML = `
        <div class="leftimages">
          <img src="${hotelData.Container['main-image']}" alt="hotel main image" class="main-image">
        </div>
        <div class="rightimages">
          <img src="${hotelData.Container['side-image']}" alt="hotel side image" class="side-image">
          <img src="${hotelData.Container['side-image2']}" alt="hotel side image2" class="side-image2">
        </div>
      `;

      const Hotelname = document.getElementsByClassName("Hotel")[0];

      Hotelname.innerHTML = `
        <h1>${hotelData.Hotel_Name}</h1>
        <div class="hotelinformation">
          <div class="abouthotel">
            <div class="review">
              <div class="number">8.8</div>
              <p>Excellent</p>
            </div>
            <p>${hotelData.description}</p>
            
            <section>
              <h4>Guests loved the amenities.</h4>
              <ul>${hotelData.amenities.map(amenity => `<li>${amenity}</li>`).join("")}</ul>
            </section>
          </div>
          <div class="hotelLocation">
            <div>
              <h4>Map address:</h4>
              <a href="${hotelData.address.mapLink}" target="_blank">
                <address>${hotelData.address.text}</address>
              </a>
            </div> 
            <aside>
              <h4>Distance</h4>
              <ul>${hotelData.distance.map(distancy => `<li>${distancy}</li>`).join("")}</ul>
            </aside>
          </div>  
        </div>
      `;
    }

    function renderRoomData(rooms) {
      const room = document.getElementById("C1");
      const roomList = document.createElement("ul");
      roomList.classList.add("Roomlist");
      rooms.forEach((room) => {
        const roomDetails = document.createElement("li");
        roomDetails.classList.add("RoomDetails");
        roomDetails.innerHTML = `
          <img src="room.webp" alt="room image">
          <div class="RoomInformation">
            <h3>${room.roomtype}</h3>
            <ul>
              <li>${room.area} sq ft</li>
              <li>${room.Wifi}</li>
              <li>Sleeps ${room.humansize}</li>
              <li>${room.bednumber}</li>
            </ul>
            <h3>Options</h3>
          <ul>
            <form action="/action_page.php">
              <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
              <label for="vehicle1"> Non-refundable</label><br>
              <input type="checkbox" id="vehicle2" name="vehicle2" value="Car">
              <label for="vehicle2"> Non-Refundable + Breakfast for 2</label><br>
              <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
              <label for="vehicle3"> Fully refundable before Oct 24 <br>+ Breakfast for 2</label><br>
              <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
              <label for="vehicle3"> Fully refundable</label><br>
            </form>
          </ul>
            <footer>
              <p>${room.price}/per day</p>
              <button class="hotelbox">Select</button>
            </footer>
          </div>
        `;
        roomList.appendChild(roomDetails);
      });
      room.appendChild(roomList);
    }

    function renderImportantInfo(data) {
      const information = document.getElementById("C2");
      information.classList.add("information");
      
      information.innerHTML = `
        <button class="scrollbox">Importantч= information</button>
        <ul class="sbox">${hotelData.important_information.map(info => `<li>${info}</li>`).join("")}</ul>
        <button class="scrollbox">Optional extras</button>
        <ul class="sbox">${hotelData.Optional_extras.map(info => `<li>${info}</li>`).join("")}</ul>
        <button class="scrollbox">You need to know</button>
        <ul class="sbox">${hotelData.You_need_to_know.map(info => `<li>${info}</li>`).join("")}</ul>
        <button class="scrollbox">We should mention</button>
        <ul class="sbox">${hotelData.we_should_mention.map(info => `<li>${info}</li>`).join("")}</ul>
      `;
    }
    function renderPolicies(policies) {
      const policy = document.getElementById("C3");
      policy.innerHTML = `<h1>Policies</h1>`; 
    
      const policiesList = document.createElement("div");
      policiesList.classList.add("Policieslist");
    
      policies.forEach((policies) => {
        const policyDiv = document.createElement("div");
        policyDiv.innerHTML = `
          <h3>${policies.title}</h3>
          <ul>
            ${policies.items.map(item => `<li>${item}</li>`).join("")}
          </ul>
        `;
        policiesList.appendChild(policyDiv);
      });
    
      policy.appendChild(policiesList);
    }

    

    function renderReviews(data) {
      const container = document.getElementById("C4");
      container.classList.add("Hotelcomment");
      
      const averageRating = data.comments.reduce((sum, comments) => sum + comments.rating, 0) / data.comments.length;
      let rating; 
      if (averageRating >= 9.0) {
        rating = "Wonderful";
      } else if (averageRating < 9.0 && averageRating >= 8.0) {
        rating = "Very Good";
      } else if (averageRating < 8.0 && averageRating >= 7.0) {
        rating = "Good";
      } else {
        rating = "No bad";
      }
      const reviewSummaryDiv = document.createElement("div");
      reviewSummaryDiv.classList.add("reviewlist");
      reviewSummaryDiv.innerHTML = `
        <div class="reviewcomment">
          <div class="total">
            <div class="number">${averageRating.toFixed(1)}</div>
            <h3>${rating}</h3>
          </div>
          <p>${data.comments.length} verified reviews</p>
        </div>
      `;
      container.appendChild(reviewSummaryDiv);
      const latestThreeComments = data.comments.slice(-3);
      latestThreeComments.forEach(comment => {
        const commentDiv = document.createElement("div");
        commentDiv.classList.add("comment");
        commentDiv.innerHTML = `
          <h1>${comment.rating}/10</h1>
          <p>${comment.author}</p>
          <p>${comment.date}</p>
          <p>${comment.stayDetails}</p>
          <div class="feedback-item">
            <p>${comment.feedback}</p>
          </div>
          <p class="final-comment">${comment.finalComment}</p>
        `;
        container.appendChild(commentDiv);
      });
    

      const seeMoreButton = document.createElement("button");
      seeMoreButton.classList.add("Ugnih");
      seeMoreButton.textContent = "See more";
      container.appendChild(seeMoreButton);
    }
    
    renderHotelInfo(hotelData);
    renderRoomData(hotelData.room);
    renderImportantInfo(hotelData);
    renderPolicies(hotelData.policies);
    renderReviews(hotelData);
  })
  .catch(error => {
    console.error('There was a problem with the fetch operation:', error);
  });
  